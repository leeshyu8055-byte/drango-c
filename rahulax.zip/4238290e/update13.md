# BioChem 專案樹狀圖（Update #13）

```
django_docker_app/
├─ README.md / Elonlogic.md / Erroreveythink.md / owasp_checklist.md / REAM.MD
├─ admin_portal.txt           # 記錄隱藏後台 URL（預設 nebula-console/）
├─ update13.md                # 本檔
├─ backups/                   # backup_tool.py 產出的 CRC32 壓縮檔
├─ bioww/
│  ├─ manage.py
│  ├─ docker-compose.yml / Dockerfile / entrypoint.sh
│  ├─ urls.example.txt        # 批次爬蟲示例清單
│  ├─ bioww/
│  │  ├─ settings.py          # DEBUG/ALLOWED_HOSTS/ADMIN_URL 等設定
│  │  ├─ urls.py              # path(settings.ADMIN_URL, admin.site.urls) + app routes
│  │  ├─ wsgi.py / asgi.py
│  │  └─ templates/
│  │     ├─ base.html
│  │     ├─ home.html
│  │     └─ partials/{footer.html, navbar.html}
│  ├─ products/
│  │  ├─ admin.py             # CSV 匯入 + 爬蟲同步 + DocumentInline
│  │  ├─ management/commands/scrape_products.py
│  │  ├─ models.py / scraper.py / urls.py / tests.py
│  │  └─ templates/products/{list.html, detail.html}
│  ├─ contact/
│  │  ├─ templates/contact/contact.html
│  │  └─ urls.py / tests.py
│  ├─ static/
│  │  └─ clone_assets/        # 由 clone_site 匯入（HTML, 圖片, SVG）
│  └─ staticfiles/ (deploy 時 collectstatic 產物，可刪除重建)
└─ backup_tool.py / restore.sh / requirements.txt
```

> `static/clone_assets` 仍保留 ChemicalBook 抽出的原始素材，可透過 `ls bioww/static/clone_assets | head` 快速確認；若要搬移至 CDN，建議保留此目錄作為「束裝圖」底稿。

---

第二次救援補救紀錄（@2🚀）

本次補救目標：
- 後台 URL 再次隱藏於 `settings.ADMIN_URL`（預設 `nebula-console/`），解決 `/admin/` 404 與文件不一致問題。
- 產品管理維持 CSV 匯入＋ChemicalBook 單頁同步，確保批量（scrape_products）與單筆（admin sync）兩種流程皆可用。
- 文件（README/Elonlogic/update13 等）全面更新為 bioww 目錄結構，供束裝圖比對。

已完成調整：
- `bioww/bioww/settings.py`：新增 `ADMIN_URL` 環境設定並正規化路徑，讓 `DJANGO_ADMIN_URL` 可被覆寫。
- `bioww/bioww/urls.py`：`path(settings.ADMIN_URL, admin.site.urls)`，避免再度忘記同步路徑而出現 404。
- `admin_portal.txt` / 所有 *.md：統一改為 `cd bioww` 指令，紀錄隱藏後台網址與調整流程。
- `README.md`：新的專案樹、Quickstart、備份路徑與任務說明皆改為 bioww。

通用 CSV 欄位（仍建議）：
```
name,sku,cas_number,formula,purity,package,min_order_kg,supply_ability,update_time,description,supplier_name,supplier_location,external_image,category,keywords
```

錯誤可能與排除表（節錄）：
- Template 找不到 partials：確認 `TEMPLATES['DIRS']` 包含 `bioww/templates`。
- ImageField 缺 Pillow：`cd bioww && pip install Pillow` 後重跑 `python manage.py check`。
- 匯入日期格式錯誤：使用 `YYYY-MM-DD`。
- Admin 同步頁 404：確認 `products/templates/admin/products/change_list.html` 仍包含「⇪ 匯入商品 / 🤖 爬蟲同步」按鈕。

恢復腳本（本庫）：
- `restore.sh` 仍會自動尋找 `bioww` 目錄並跑 `manage.py check / migrate / collectstatic`（若虛擬環境就緒）。
- 若尚未安裝 Django/venv，腳本會略過但不報錯，可依 README 快速建立。
