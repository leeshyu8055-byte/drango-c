Bioww 容器部署與一次鏡像同步（Ubuntu 22.04）

概要
- 本文件教你在 Ubuntu 22.04 安裝 Docker/Compose，啟動 bioww（Django + Gunicorn），以及「一次鏡像同步」的操作方式（批次與單筆）。
- 也包含常見錯誤排除（埠被占用、Compose v1 與 v2 差異、daemon 未啟動等）。

事前準備
- 建議使用 Docker 官方來源（含 Compose v2）：
  - sudo apt update && sudo apt install -y ca-certificates curl gnupg
  - sudo install -m 0755 -d /etc/apt/keyrings
  - curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  - echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release; echo $VERSION_CODENAME) stable" | sudo tee /etc/apt/sources.list.d/docker.list >/dev/null
  - sudo apt update
  - sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  - sudo systemctl enable --now docker
  - docker --version && docker compose version

啟動專案（bioww 目錄）
- 進到專案：
  - cd bioww
- 建置與啟動（Compose v2）：
  - docker compose build
  - docker compose up -d
- 建立管理者：
  - docker compose exec web python manage.py createsuperuser
- 檢視狀態與日誌：
  - docker ps
  - docker compose logs -f web
- 瀏覽：
  - http://<server-ip>:8000

一次鏡像同步（批次）
- 準備網址清單（每行一個商品頁 URL；請確保你有權限抓取該內容）：
  - 建立檔案（容器內路徑 /app/urls.txt）：
    - 在主機：將檔案放在 bioww/urls.txt（容器會掛載整個專案到 /app）
    - 範例：見 bioww/urls.example.txt（請自行改為有效 URL）
- 執行批次爬取並寫入資料庫：
  - cd bioww
  - docker compose exec web python manage.py scrape_products --urls-file /app/urls.txt --concurrency 4 --delay 1.0
- 選用：同時輸出 CSV：
  - docker compose exec web python manage.py scrape_products --urls-file /app/urls.txt --concurrency 4 --delay 1.0 --csv-out /app/out.csv

- 一次鏡像同步（單筆，管理後台）
- 打開 `/<ADMIN_URL>/`（預設 `nebula-console/`；可在 `bioww/bioww/settings.py` 或 `admin_portal.txt` 查閱）→ Products → 右上角按鈕「🤖 爬蟲同步」
- 輸入商品 URL（可選填 SKU 與分類）→ 送出後即會建立/更新該商品。

埠 8000 被占用時
- 釋放 8000：
  - sudo ss -ltnp | grep ':8000'
  - 若為容器：docker ps --format '{{.Names}}\t{{.Ports}}' | grep 8000；docker stop <name>; docker rm <name>
- 或改用 8080：
  - 編輯 bioww/docker-compose.yml → ports 改為 "8080:8000"
  - docker compose up -d --force-recreate
  - 瀏覽 http://<server-ip>:8080

Compose v1/v2 差異與安裝
- 若系統僅有 v1：
  - 安裝：sudo apt install -y docker-compose
  - 指令改用：docker-compose build / docker-compose up -d / docker-compose logs -f web
- 建議使用 v2（上方安裝步驟）。

Docker daemon 未啟動
- 錯誤："Cannot connect to the Docker daemon at unix:///var/run/docker.sock"
- 解法：
  - sudo systemctl enable --now docker
  - sudo systemctl status docker
  - docker info

代理與大量抓取（選用）
- 預設爬蟲會遵守 robots.txt 並進行重試與速率限制。
- 若你有合法代理環境，可在 docker-compose.yml（web.environment）加入：
  - SCRAPER_HTTP_PROXY=http://host.docker.internal:8080
  - SCRAPER_HTTPS_PROXY=http://host.docker.internal:8080

常用維運指令
- 進入容器 shell：docker compose exec web bash
- 套件同步：docker compose exec web pip install -r requirements.txt
- 收靜態檔：docker compose exec web python manage.py collectstatic --noinput
- 建資料庫：docker compose exec web python manage.py migrate
- 重建：docker compose down -v --remove-orphans && docker compose build --no-cache && docker compose up -d
- 停止：docker compose down

備份建議
- 在專案根目錄（非容器內）使用備份工具：
  - python3 backup_tool.py --root bioww --dest backups --exclude staticfiles --exclude venv
  - 會在 backups/ 生成以 CRC32 命名的 zip 檔。

附錄：urls.example.txt 範例（請換成你有權限的目標）
```
https://example.com/product/123
https://example.com/product/456
```

注意事項
- 請遵守目標網站的條款、robots.txt 與法規要求，並取得必要授權。
- 本專案不包含任何繞過網站防護的功能；如需進階傳輸層設定，請在合法前提下替換 scraper 的傳輸層實作。
