import csv
import io
from datetime import datetime

from django import forms
from django.contrib import admin, messages
from django.shortcuts import redirect, render
from django.urls import path

from .models import Category, Product, Document


class ProductImportForm(forms.Form):
    file = forms.FileField(
        help_text='UTF-8 CSV：name, sku, cas_number, formula, purity, package, min_order_kg, '
                  'supply_ability, update_time(YYYY-MM-DD), description, supplier_name, '
                  'supplier_location, external_image, category, keywords'
    )


class ProductSyncForm(forms.Form):
    url = forms.URLField(label='ChemicalBook 商品頁 URL', required=True)
    sku = forms.CharField(label='SKU（選填）', required=False)
    category = forms.CharField(label='分類名稱（選填）', required=False)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent')
    search_fields = ('name',)


class DocumentInline(admin.TabularInline):
    model = Document
    extra = 0


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'sku', 'category', 'supplier_name', 'update_time')
    list_filter = ('category',)
    search_fields = ('name', 'sku', 'cas_number')
    inlines = [DocumentInline]
    change_list_template = 'admin/products/change_list.html'

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path('import-data/', self.admin_site.admin_view(self.import_products), name='products_product_import'),
            path('sync/', self.admin_site.admin_view(self.sync_product_from_url), name='products_product_sync'),
        ]
        return custom + urls

    def import_products(self, request):
        if request.method == 'POST':
            form = ProductImportForm(request.POST, request.FILES)
            if form.is_valid():
                file_obj = form.cleaned_data['file']
                data = io.StringIO(file_obj.read().decode('utf-8'))
                reader = csv.DictReader(data)
                created = 0
                updated = 0
                for row in reader:
                    if not row.get('sku'):
                        continue
                    category_name = row.get('category') or 'General'
                    category, _ = Category.objects.get_or_create(name=category_name)
                    defaults = {
                        'name': row.get('name', '').strip(),
                        'category': category,
                        'formula': row.get('formula', ''),
                        'cas_number': row.get('cas_number', ''),
                        'purity': row.get('purity', ''),
                        'package': row.get('package', ''),
                        'supply_ability': row.get('supply_ability', ''),
                        'description': row.get('description', ''),
                        'supplier_name': row.get('supplier_name', ''),
                        'supplier_location': row.get('supplier_location', ''),
                        'external_image': row.get('external_image', ''),
                        'keywords': row.get('keywords', ''),
                    }
                    if row.get('min_order_kg'):
                        try:
                            defaults['min_order_kg'] = float(row['min_order_kg'])
                        except ValueError:
                            pass
                    if row.get('update_time'):
                        try:
                            defaults['update_time'] = datetime.strptime(row['update_time'], '%Y-%m-%d').date()
                        except ValueError:
                            pass
                    product, created_flag = Product.objects.update_or_create(
                        sku=row['sku'],
                        defaults=defaults,
                    )
                    if created_flag:
                        created += 1
                    else:
                        updated += 1

                messages.success(request, f'導入完成：新增 {created} 筆，更新 {updated} 筆。')
                return redirect('..')
        else:
            form = ProductImportForm()
        context = {**self.admin_site.each_context(request), 'opts': self.model._meta, 'form': form}
        return render(request, 'admin/products/import.html', context)

    def sync_product_from_url(self, request):
        try:
            from .scraper import scrape_product
        except Exception:
            scrape_product = None

        if request.method == 'POST':
            form = ProductSyncForm(request.POST)
            if form.is_valid():
                url = form.cleaned_data['url']
                sku = form.cleaned_data.get('sku') or ''
                cat_name = form.cleaned_data.get('category') or ''
                if not scrape_product:
                    messages.error(request, 'scraper.py 尚未就緒，請先建立爬蟲模組。')
                    return redirect('..')
                try:
                    data = scrape_product(url)
                except Exception as exc:
                    messages.error(request, f'同步失敗：{exc}')
                    return redirect('..')
                category_obj = None
                if cat_name:
                    category_obj, _ = Category.objects.get_or_create(name=cat_name)
                # 產生後備 SKU（避免必填/唯一約束導致建立失敗）
                if not sku:
                    base = (data.name or 'product').strip().replace(' ', '-')[:40]
                    sku = f"AUTO-{base}"
                lookup = {'sku': sku}
                defaults = {
                    'name': data.name,
                    'category': category_obj or Category.objects.first(),
                    'cas_number': getattr(data, 'cas_number', '') or '',
                    'purity': getattr(data, 'purity', '') or '',
                    'package': getattr(data, 'package', '') or '',
                    'supply_ability': getattr(data, 'supply_ability', '') or '',
                    'description': (getattr(data, 'short_description', '') or '')[:5000],
                    'external_image': getattr(data, 'image_url', '') or '',
                    'supplier_name': getattr(data, 'supplier_name', '') or '',
                    'supplier_location': getattr(data, 'supplier_location', '') or '',
                }
                try:
                    product, created = Product.objects.update_or_create(**lookup, defaults=defaults)
                except Exception as exc:
                    messages.error(request, f'儲存失敗：{exc}')
                    return redirect('..')
                messages.success(request, f'{"建立" if created else "更新"}完成：{product.name}')
                return redirect('..')
        else:
            form = ProductSyncForm()
        ctx = {**self.admin_site.each_context(request), 'opts': self.model._meta, 'form': form, 'title': '🤖 爬蟲同步（ChemicalBook）'}
        return render(request, 'admin/products/sync.html', ctx)
