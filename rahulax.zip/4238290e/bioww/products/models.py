from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=120)
    parent = models.ForeignKey(
        'self', on_delete=models.CASCADE, null=True, blank=True, related_name='children'
    )
    description = models.TextField(blank=True)

    class Meta:
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=200)
    sku = models.CharField(max_length=50, unique=True)
    formula = models.CharField(max_length=100, blank=True)
    cas_number = models.CharField(max_length=50, blank=True)
    molecular_weight = models.DecimalField(max_digits=10, decimal_places=3, null=True, blank=True)
    ec_number = models.CharField(max_length=50, blank=True)
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    external_image = models.URLField(blank=True)
    category = models.ForeignKey('Category', on_delete=models.SET_NULL, null=True, related_name='products')
    price = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True)
    description = models.TextField(blank=True)
    purity = models.CharField(max_length=100, blank=True)
    package = models.CharField(max_length=100, blank=True)
    min_order_kg = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    supply_ability = models.CharField(max_length=100, blank=True)
    update_time = models.DateField(null=True, blank=True)
    release_date = models.DateField(null=True, blank=True)
    supplier_name = models.CharField(max_length=200, blank=True)
    supplier_location = models.CharField(max_length=120, blank=True)
    keywords = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.sku})"


class Document(models.Model):
    DOC_TYPES = [
        ('COA', 'Certificate of Analysis'),
        ('COO', 'Certificate of Origin'),
        ('SDS', 'Safety Data Sheet'),
    ]

    product = models.ForeignKey('Product', on_delete=models.CASCADE, related_name='documents')
    doc_type = models.CharField(max_length=10, choices=DOC_TYPES)
    file = models.FileField(upload_to='documents/')

    def __str__(self):
        return f"{self.product.name} - {self.doc_type}"

