from __future__ import annotations

import dataclasses
import datetime
import time
from typing import Optional
import os

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from urllib import robotparser
from bs4 import BeautifulSoup


@dataclasses.dataclass
class ScrapedProduct:
    name: str
    sku: str | None = None
    cas_number: str | None = None
    purity: str | None = None
    package: str | None = None
    min_order_quantity: str | None = None
    supply_ability: str | None = None
    short_description: str | None = None
    long_description: str | None = None
    image_url: str | None = None
    source_url: str | None = None
    updated_at: datetime.datetime | None = None
    category_name: str | None = None


class ScrapeError(Exception):
    pass

def _default_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.7",
    })
    retry = Retry(total=3, backoff_factor=0.5, status_forcelist=(429, 500, 502, 503, 504))
    adapter = HTTPAdapter(max_retries=retry)
    s.mount('http://', adapter)
    s.mount('https://', adapter)
    # Optional proxy support via env var SCRAPER_HTTP_PROXY / SCRAPER_HTTPS_PROXY
    http_proxy = os.getenv('SCRAPER_HTTP_PROXY')
    https_proxy = os.getenv('SCRAPER_HTTPS_PROXY')
    proxies = {}
    if http_proxy:
        proxies['http'] = http_proxy
    if https_proxy:
        proxies['https'] = https_proxy
    if proxies:
        s.proxies.update(proxies)
    return s


def get_transport() -> requests.Session:
    """Return a session-like transport.

    Advanced users can replace this to provide a custom compliant transport.
    It must implement .get(url, timeout=..., headers=...) and return a Response-like object with .status_code and .text.
    """
    return _default_session()


def _allowed_by_robots(url: str, ua: str) -> bool:
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        rp = robotparser.RobotFileParser()
        rp.set_url(robots_url)
        rp.read()
        return rp.can_fetch(ua, url)
    except Exception:
        return True


def scrape_product(url: str, *, delay: float = 0.0) -> ScrapedProduct:
    session = get_transport()
    ua = session.headers.get("User-Agent", "Mozilla/5.0")
    if not _allowed_by_robots(url, ua):
        raise ScrapeError("Blocked by robots.txt policy for the current User-Agent.")

    if delay > 0:
        time.sleep(delay)

    resp = session.get(url, timeout=30)
    if resp.status_code != 200:
        raise ScrapeError(f"HTTP {resp.status_code} while scraping {url}")
    soup = BeautifulSoup(resp.text, 'html.parser')

    # Basic extraction (site-specific mapping can be extended)
    name_tag: Optional[object] = soup.find('h1')
    if not name_tag:
        raise ScrapeError('Product name not found')

    # best-effort fallback selectors for description and image
    desc_tag = soup.select_one('.product-description, #description, article, .content')
    img_tag = soup.select_one('img.product-image, .gallery img, img')

    return ScrapedProduct(
        name=name_tag.get_text(strip=True),
        short_description=(desc_tag.get_text(strip=True) if desc_tag else ''),
        long_description=(desc_tag.get_text(strip=True) if desc_tag else ''),
        image_url=(img_tag.get('src') if img_tag and img_tag.get('src') else ''),
        source_url=url,
        updated_at=datetime.datetime.utcnow(),
    )
