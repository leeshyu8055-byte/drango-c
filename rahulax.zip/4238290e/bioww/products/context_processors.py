from .models import Category


def navigation_categories(request):
    return {
        'popular_categories': Category.objects.all()[:6]
    }

