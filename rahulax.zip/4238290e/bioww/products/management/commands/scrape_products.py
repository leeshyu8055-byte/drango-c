from __future__ import annotations

import csv
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from products.models import Category, Product
from products.scraper import scrape_product, ScrapeError


def iter_urls(path: Path) -> Iterable[str]:
    with path.open('r', encoding='utf-8') as fh:
        for line in fh:
            u = line.strip()
            if u and not u.startswith('#'):
                yield u


class Command(BaseCommand):
    help = "Scrape product pages from a URL list and upsert Products politely."

    def add_arguments(self, parser):
        parser.add_argument('--urls-file', type=str, help='Path to a text file with one URL per line')
        parser.add_argument('--concurrency', type=int, default=4, help='Max concurrent requests (default: 4)')
        parser.add_argument('--delay', type=float, default=0.5, help='Delay seconds per request (default: 0.5)')
        parser.add_argument('--category', type=str, default='', help='Optional category name for all imported products')
        parser.add_argument('--csv-out', type=str, default='', help='Optional path to write scraped results as CSV')

    def handle(self, *args, **options):
        urls_file = options['urls_file']
        if not urls_file:
            raise CommandError('--urls-file is required')
        urls_path = Path(urls_file)
        if not urls_path.exists():
            raise CommandError(f'File not found: {urls_path}')

        urls = list(iter_urls(urls_path))
        if not urls:
            self.stdout.write(self.style.WARNING('No URLs to process.'))
            return

        category_name = (options['category'] or '').strip()
        category_obj = None
        if category_name:
            category_obj, _ = Category.objects.get_or_create(name=category_name)

        results = []
        created, updated, failed = 0, 0, 0
        self.stdout.write(f"Scraping {len(urls)} URLs with concurrency={options['concurrency']} delay={options['delay']}s")

        with ThreadPoolExecutor(max_workers=options['concurrency']) as executor:
            fut_map = {
                executor.submit(scrape_product, url, delay=options['delay']): url for url in urls
            }
            for fut in as_completed(fut_map):
                url = fut_map[fut]
                try:
                    data = fut.result()
                except ScrapeError as exc:
                    failed += 1
                    self.stderr.write(self.style.ERROR(f"[FAIL] {url} :: {exc}"))
                    continue
                results.append(asdict(data))

                # Upsert into DB (SKU may be empty; generate fallback)
                sku = (data.sku or f"AUTO-{data.name.strip().replace(' ', '-')[:40]}")
                defaults = {
                    'name': data.name,
                    'category': category_obj or Category.objects.first(),
                    'cas_number': (data.cas_number or ''),
                    'purity': (data.purity or ''),
                    'package': (data.package or ''),
                    'supply_ability': (data.supply_ability or ''),
                    'description': (data.short_description or '')[:5000],
                    'external_image': (data.image_url or ''),
                }
                with transaction.atomic():
                    product, is_created = Product.objects.update_or_create(sku=sku, defaults=defaults)
                if is_created:
                    created += 1
                else:
                    updated += 1
                self.stdout.write(self.style.SUCCESS(f"[OK] {product.name} ({sku})"))

        if options['csv_out']:
            out_path = Path(options['csv_out'])
            with out_path.open('w', encoding='utf-8', newline='') as fh:
                writer = csv.DictWriter(fh, fieldnames=list(results[0].keys()) if results else [])
                if results:
                    writer.writeheader()
                    for row in results:
                        writer.writerow(row)
            self.stdout.write(self.style.SUCCESS(f"CSV written: {out_path}"))

        self.stdout.write(self.style.MIGRATE_HEADING(
            f"Done. created={created} updated={updated} failed={failed}"
        ))

