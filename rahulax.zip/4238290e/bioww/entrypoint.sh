#!/usr/bin/env bash
set -euo pipefail

cd /app

if [ -f manage.py ]; then
  python manage.py makemigrations products contact || true
  python manage.py migrate --noinput || true
  python manage.py collectstatic --noinput || true
fi

# Use gunicorn in container; fallback to runserver in dev
if command -v gunicorn >/dev/null 2>&1; then
  exec gunicorn bioww.wsgi:application --bind 0.0.0.0:8000 --workers 3
else
  exec python manage.py runserver 0.0.0.0:8000
fi
