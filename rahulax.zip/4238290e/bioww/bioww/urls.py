from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from django.conf import settings
from django.conf.urls.static import static

admin_path = getattr(settings, 'ADMIN_URL', 'admin/')

urlpatterns = [
    path(admin_path, admin.site.urls),
    path('', TemplateView.as_view(template_name='home.html'), name='home'),
    path('products/', include('products.urls')),
    path('contact/', include('contact.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
